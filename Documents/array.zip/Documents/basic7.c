#include <stdio.h>
int main()
{
	int a,b,c;
	printf("enter the value of a\n");
	scanf("%d",&a);
	printf("enter the value of b\n");
	scanf("%d",&b);
	c=a;
	a=b;
	b=c;
	printf("a is:%d\n",a);
	printf("b is:%d\n",b);
	return 0;
}
