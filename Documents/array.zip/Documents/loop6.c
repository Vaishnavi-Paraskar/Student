#include<stdio.h>
int main()
{
	int m,n;
	printf("enter the number m: ");
	scanf("%d",&m);
	printf("enter the number n: ");
	scanf("%d",&n);
	for(; m<=n; m++)
	{
	  if(m%2==0 && m%7==0)
	  {
	    printf("%d\n",m);
	  }
	}
	return 0;
}
	
	
	
