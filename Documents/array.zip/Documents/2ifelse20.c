#include<stdio.h>
int main()
{
	int a,cost,totalcost,d;
	printf("enter the quantity\n");
	scanf("%d",&a);
	cost=a*100;
	d=(cost*10)/100;
        totalcost=cost-d;
        if (cost > 1000){
	printf("%d\n",totalcost);
	}else{
	printf("%d\n",cost);
	}
	return 0;
}
