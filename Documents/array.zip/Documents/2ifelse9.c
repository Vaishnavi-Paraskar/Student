// 10) Program To Check No Is Largest 3 Digit No Or Not

#include <stdio.h>
int main()
{
	int a;
	printf("enter the value of a\n");
	scanf("%d",&a);
	if ( a == 999){
	printf("it is a largest 3 digit no\n");
	}else{
	printf("it is not a largest 3 digit no\n");
	}
	return 0;
}
