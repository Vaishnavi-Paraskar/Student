#include <stdio.h>
int main()
{
	int a,b,P,Q,R,S;
	printf("enter the value of a\n");
	scanf("%d",&a);
	printf("enter the value of b\n");
	scanf("%d",&b);
	P=a+b;
	Q=a-b;
	R=a*b;
	S=a/b;
	printf("P is:%d\n",P);
	printf("Q is:%d\n",Q);
	printf("R is:%d\n",R);
	printf("S is:%d\n",S);
	return 0;
}
