#include<stdio.h>
int main()
{
	int a,b,c;
	printf("enter the number\n");
	scanf("%d",&a);
	printf("enter the number\n");
	scanf("%d",&b);
	printf("enter the number\n");
	scanf("%d",&c);
	if (a > b){
		if (a > c){
		printf("a is maximum\n");
		}else{
		printf("c is maximum\n");
		}
	}else if(b > c){
	printf("b is maximum\n");
	}else{
	printf("c is maximum\n");
	}
	return 0;
}
