#include <stdio.h>
int main()
{
	int age;
	printf("enter the age of the person\n");
	scanf("%d",&age);
	if ( age >=60){
	printf("person is senior citizen\n");
	}else{
	printf("person is not senior citizen\n");
	}
	return 0;
}
