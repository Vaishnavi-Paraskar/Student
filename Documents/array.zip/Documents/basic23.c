#include<stdio.h>
int main()
{
	int mrp,D,SP;
	printf("enter the mrp of product\n");
	scanf("%d",&mrp);
	printf("enter the value of discount\n");
	scanf("%d",&D);
	SP=mrp-D;
	printf("selling price of a product is:%d\n",SP);
	return 0;
}
