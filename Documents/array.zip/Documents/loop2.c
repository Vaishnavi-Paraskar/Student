#include<stdio.h>
int main()
{
	int n,i,sum,m;
	n=15;
	sum=0;
	m=2;
	for(i=1; i<=n; i++)
	{
	sum+=m;
	m+=2;
	}
	printf("sum of first 15 even numbers: %d\n",sum);
	return 0;
}
