#include<stdio.h>
int main()
{
	int a[10]={};
	int p[10]={};
	for(int i=0; i<10; i++){
	int k;
	printf("enter the value of k: ");
	scanf("%d",&k);
	a[i]=k;
	}
	int j=0;
	for(int i=10-1; i>=0; i--){
	p[j]=a[i];
	j++;
	}
	for(int j=0; j<10; j++){
	printf("p[%d]= %d\n",j,p[j]);
	}
	return 0;
} 
