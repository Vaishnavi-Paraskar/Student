#include<stdio.h>     
int main()
{
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	float sum=0;
	for(int i=1; i<=n; i++){
	sum=sum+1.0/i;
	}
	printf("%f\n",sum);
	return 0;
}
