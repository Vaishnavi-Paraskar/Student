#include<stdio.h>
int main()
{
	int a,feet;
	printf("enter the height of children in inches\n");
	scanf("%d",&a);
	feet=a/12;
	printf("%d\n",feet);
	if (feet >= 5){
	printf("he/she is allowed to ride\n");
	}else{
	printf("he/she is not allowed to ride\n");
	}
	return 0;
}
	
