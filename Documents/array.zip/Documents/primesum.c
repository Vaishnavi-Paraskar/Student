// prime numbers between 1 to N

#include<stdio.h>
int main()
{
	int n;
	int sum=0;
	printf("enter the number\n");
	scanf("%d",&n);
	for(int i=1; i<=n; i++){
	int count=0;
	for(int j=1; j<=i; j++){
	if(i%j==0){
	count=count+1;
	}
	}
	if(count==2){
	sum=sum+i;
	}
	}
	printf("sum: %d\n",sum);
	return 0;
}
	
