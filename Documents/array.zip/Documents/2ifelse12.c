#include <stdio.h>
int main()
{
	int a,lastdigit;
	printf("enter the value of a\n");
	scanf("%d",&a);
	lastdigit==a%10;
	if (lastdigit%3 == 0){
	printf("lastdigit is divisible by 3\n");}
	else{
	printf("lastdigit is not divisible by 3\n");
	}
	return 0;
}
