#include<stdio.h>
int main()
{
int a,b,total;
printf("enter the score of B.pharm: ");
scanf("%d",&a);
printf("enter the score of D.pharm: ");
scanf("%d",&b);
total=a+b;
if(a>20){
if(b>20){
if(total>45){
printf("pass: %d\n",total);
}else if(total>=44){
total=45;
printf("pass: %d\n",total);
}else{
printf("fail: %d\n",total);
}
}else if(total>45){
total=44;
printf("technical fail: %d\n",total);
}else{
printf("fail: %d\n",total);
}
}else if(b>20){
if(total>45){
total=44;
printf("technical fail: %d\n",total);
}else{
printf("fail: %d\n",total);
}
}else{
printf("fail: %d\n",total);
}
return 0;
}
	
