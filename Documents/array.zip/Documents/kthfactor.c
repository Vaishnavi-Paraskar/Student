// K th largest factor of given no

#include<stdio.h>
int main()
{
	int n,k;
	printf("enter the number n: ");
	scanf("%d",&n);
	printf("enter the number k: ");
	scanf("%d",&k);
	int count=0;
	for(int i=n; i>=1; i--){
	if(n%i==0){
	count=count+1;
	if(count==k){
	printf("k th largest factor: %d\n",i);
	}
	}
	}
	return 0;
}
	
