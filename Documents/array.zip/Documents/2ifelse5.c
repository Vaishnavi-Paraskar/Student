#include<stdio.h>
int main()
{
	int sp,cp,loss,p;
	printf("enter the selling price\n");
	scanf("%d",&sp);
	printf("enter the cost price\n");
	scanf("%d",&cp);
	if (sp < cp){
	loss=cp-sp;
	printf("loss: %d\n",loss);
	p=(loss*100)/sp;{
	printf("percentage: %d\n",p);
	}
	}else{
	printf("invalid\n");
	}
	return 0;
}
	
