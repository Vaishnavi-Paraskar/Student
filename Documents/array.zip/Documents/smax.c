#include<stdio.h>
int main()
{
	int n,a;
	printf("enter the number: ");
	scanf("%d",&n);
	printf("enter the number a: ");
	scanf("%d",&a);
	int max=a;
	int smax=a;
	for(int i=1; i<n; i++){
	printf("enter the number a: ");
	scanf("%d",&a);
	if(a>max){
	smax=max;
	max=a;
	}else if(a>smax){
	smax=a;
	}
	}
	printf("second max: %d\n",smax);
	return 0;
}
