                   // HCF of N given number

#include<stdio.h>
int main()
{
	int n,a,r;
	printf("enter the number: ");
	scanf("%d",&n);
	int hcf=0;
	for(int i=1; i<n; i++){
	printf("enter the number a: ");
	scanf("%d",&a);
	while(a!=0){
	r=hcf%a;
	hcf=a;
	a=r;
	}
	}
	printf("%d\n",hcf);
	return 0;
}
	
	
