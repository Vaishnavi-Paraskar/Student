#include<stdio.h>
int main()
{
	int num;
	printf("enter the number\n");
	scanf("%d",&num);
	printf("the square of number is:%d\n",num*num);
	return 0;
}
