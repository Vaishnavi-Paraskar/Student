#include<stdio.h>
int main()
{
	int n,i;
	n=100;
	for(i=1; i<n; i++){
	if (i%7==0)
	printf("%d\n",i);
	}
	return 0;
}
	
