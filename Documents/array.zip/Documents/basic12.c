#include <stdio.h>
int main()
{
	float side,A,P;
	printf("enter the side of square\n");
	scanf("%f",&side);
	A =side*side;
	P=4*side;
	printf("area is:%f\n",A);
	printf("perimeter is:%f\n",P);
	return 0;
}

