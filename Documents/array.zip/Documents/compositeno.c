#include<stdio.h>
int main()
{
	int m,n;
	printf("enter the number m: ");
	scanf("%d",&m);
	printf("enter the number n: ");
	scanf("%d",&n);
	for(; m<=n; m++){
	int count=0;
	for(int j=1; j<=m; j++){
	if(m%j==0){
	count=count+1;
	}
	}if(count>2){
	printf("%d\n",m);
	}
	}
	return 0;
}
