#include <stdio.h>
int main()
{
	int b,h,Area;
	printf("enter the base of triangle\n");
	scanf("%d",&b);
	printf("enter the height of triangle\n");
	scanf("%d",&h);
	Area=(b*h)/2;
	printf("area of a triangle: %d\n",Area);
	return 0;
}


