#include<stdio.h>
int main()
{
	int a,b,c;
	printf("enter the number\n");
	scanf("%d",&a);
	printf("enter the number\n");
	scanf("%d",&b);
	c=a+b;
	if (c > 15 && c < 20){
	printf("20\n");
	}else{
	printf("invalid\n");
	}
	return 0;
}
	
