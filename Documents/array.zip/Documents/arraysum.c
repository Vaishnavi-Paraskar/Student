#include<stdio.h>
int main()
{
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	int p;
	printf("enter the number p: ");
	scanf("%d",&p);
	int k[n];
	for(int i=0; i<n; i++){
	int a;
	printf("enter the number a: ");
	scanf("%d",&a);
	k[i]=a;
	}
	for(int i=0; i<(n-1); i++){
	int sum=0;
	sum=k[i]+k[i+1];
	if(sum==p){
	printf("%d + %d = %d\n",k[i],k[i+1],p);
	}
	}
	return 0;
}
	
