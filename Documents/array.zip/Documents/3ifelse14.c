#include<stdio.h>
int main()
{
	int a;
	printf("enter the year\n");
	scanf("%d",&a);
	if (a % 400 == 0){
	printf("year is divisible 400\n");
	}else{
	printf("year is not divisible by 400\n");
	}
	return 0;
}
