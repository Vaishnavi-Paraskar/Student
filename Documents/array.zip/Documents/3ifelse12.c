#include<stdio.h>
int main()
{
	int a;
	printf("enter a year\n");
	scanf("%d",&a);
	if (a%4==0){
	printf("year is a leap year\n");
	}else if(a%100==0){
	printf("year is not a leap year\n");
	}else if(a%400==0){
	printf("year is a leap year\n");
	}else{
	printf("year is not a leap year\n");
	}
	return 0;
}
