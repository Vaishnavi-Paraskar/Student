#include<stdio.h>
int main()
{
	float AB,BC,CD,DA,I;
	printf("enter the value of AB\n");
	scanf("%f",&AB);
	printf("enter the value of AB\n");
	scanf("%f",&BC);
	printf("enter the value of AB\n");
	scanf("%f",&CD);
	printf("enter the value of AB\n");
	scanf("%f",&DA);
	printf("enter the value of I\n");
	scanf("%f",&I);
	if (AB==BC)
		if (BC==CD)
			if(CD==DA)
				if (I==90){
				printf("square\n");
				}else{
				printf("rhombus\n");
				}
			else{
			printf("irregular quadrilateral\n");
			}
		else{
		printf("irregular quadrilateral\n");
		}
	else if (AB==CD)
		if (BC==DA)
			if (I==90){
			printf("ractangle\n");
			}else{
			printf("parallelogram\n");
			}
		else{
		printf("irregular quadrilateral\n");
		}
	else{
	printf("irregular quadrilateral\n");
	}
	return 0;
}
		
		
			
		
			
				
	
	
