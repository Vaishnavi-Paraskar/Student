#include<stdio.h>
int main()
{
	int x,y;
	float z;
	printf("enter the amount\n");
	scanf("%d",&x);
	printf("enter the price of a book\n");
	scanf("%d",&y);
	z=x/y;
	printf("books we can buy:%f\n",z);
	return 0;
}
	
