#include<stdio.h>
int main()
{
	char str[9];
	printf("enter the word\n");
	scanf("%s",str);
	printf("welcome %s\n",str);
	return 0;
}
