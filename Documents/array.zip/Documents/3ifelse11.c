#include<stdio.h>
int main()
{
	float rh,cc,ts;
	printf("enter the value of rh\n");
	scanf("%f",&rh);
	printf("enter the value of cc\n");
	scanf("%f",&cc);
	printf("enter the value of ts\n");
	scanf("%f",&ts);
	if (rh > 50)
		if( ts > 5600)
			if (cc > 0.7){
			printf("Grade 10\n");
			}else{
			printf("Grade 7\n");
			}
		else if(cc > 0.7){
		printf("Grade 9\n");
		}else{
		printf("0\n");
		}
	else if(ts > 5600)
		if(cc > 0.7){
		printf("Grade 8\n");
		}else{
		printf("0\n");
		}
	else{
	printf("0\n");
	}
	return 0;
}
