#include<stdio.h>
int main()
{
	int n,charge;
	printf("enter the number of days\n");
	scanf("%d",&n);
	if (n <= 5){
	charge=n*2;
	printf("%d",charge);
	}
	else if(n <= 10){
	charge=(5*2+(n-5))*3;
	printf("%d",charge);
	}
	else if(n <= 15){
	charge=(5*2+5*3+(n-10))*4;
	printf("%d",charge);
	}
	else{
	charge=(5*2+5*3+5*4+(n-15))*5;
	printf("d",charge);
	}
	return 0;
}
	
	
