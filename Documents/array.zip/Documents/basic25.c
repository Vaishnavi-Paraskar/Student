#include<stdio.h>
int main()
{
	int num;
	printf("enter the number\n");
	scanf("%d",&num);
	printf("the cube of number is:%d\n",num*num*num);
	return 0;
}

