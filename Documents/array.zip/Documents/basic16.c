#include <stdio.h>
int main()
{
	float a,LSA,TSA;
	printf("enter the side of a cube\n");
	scanf("%f",&a);
	LSA=4*a*a;
	TSA=6*a*a;
	printf("lateral surface area of cube is:%f\n",LSA);
	printf("total surface area of cube is:%f\n",TSA);
	return 0;
}
