#include <stdio.h>
int main()
{
	int p,r,t;
	printf("enter the amount\n");
	scanf("%d",&p);
	printf("enter the rate of interest\n");
	scanf("%d",&r);
	printf("enter time of interest\n");
	scanf("%d",&t);
	float SI;
	SI=(p*r*t)/100;
	printf("simple interest: %f",SI);
	return 0;
}
