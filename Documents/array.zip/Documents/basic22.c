#include <stdio.h>
int main()
{
	float a,b;
	float Q;
	printf("enter the number\n");
	scanf("%f",&a);
	printf("enter the number\n");
	scanf("%f",&b);	
	Q=a/b;
	printf("quotient of number is:%f\n",Q);
	return 0;
}
