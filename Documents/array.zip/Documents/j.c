#include<stdio.h>
int main()
{
int a,b,c,total,m,f;
printf("enter the age of the person: ");
scanf("%d",&a);
printf("enter the number of the days: ");
scanf("%d",&b);
char ch;
getchar();
printf("enter the gender of the person: ");
scanf("%c",&ch);
if(ch==m){
if(a>=18){
if(a<30){
total=700*b;
printf("%d",total);
}else if(a>=30){
if(a<=40){
total=800*b;
printf("%d",total);
}else{
printf("enter appropriate age\n");
}else{
printf("enter appropriate age\n");
}else{
printf("enter appropriate age\n");
}
}
}else if(ch==f){
if(a>=18){
if(a<30){
total=750*b;
printf("%d",total);
}else if(a>=30){
if(a<=40){
total=850*b;
printf("%d",total);
}else{
printf("enter appropriate age\n");
}else{
printf("enter appropriate age\n");
}else{
printf("enter appropriate age\n");
}
}
}
}
return 0;
}
}
