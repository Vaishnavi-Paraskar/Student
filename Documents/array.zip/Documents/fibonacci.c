#include<stdio.h>
int main()
{
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	int a=0;
	int i=1;
	int sum=0;
	for(int c=1; c<=n; c++){
	printf("%d\n",sum);
	a=i;
	i=sum;
	sum=a+i;
	}
	return 0;
}
