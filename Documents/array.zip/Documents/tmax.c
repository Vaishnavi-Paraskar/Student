some test cases fail

#include<stdio.h>
int main()
{
	int n,a;
	printf("enter the number: ");
	scanf("%d",&n);
	int max=0;
	int smax=0;
	int tmax=0;
	for(int i=1; i<=n; i++){
	printf("enter the number a: ");
	scanf("%d",&a);
	if(a>max){
	tmax=smax;
	smax=max;
	max=a;
	}else if(a>smax){
	tmax=smax;
	smax=a;
	}else if(a>tmax){
	tmax=a;
	}
	}
	printf("max: %d\nsmax: %d\ntmax: %d\n",max,smax,tmax);
	return 0;
}
