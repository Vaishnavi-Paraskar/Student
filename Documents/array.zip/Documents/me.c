#include <stdio.h>
#include <math.h>

int main()
{
    int n;
    printf("Enter the number: ");
    scanf("%d", &n);
    
    int c = 0;
    int p = n;
    
    while (p != 0) {
        int r = p % 10;
        c = c + 1;
        p = p / 10;
    }
    
    printf("Count: %d\n", c);
    
    int sum = 0;
    int m = n;
    
    while (m != 0) {
        int q = m % 10;
        sum = sum + pow(q, c);
        m = m / 10;
    }
    
    if (sum == n) {
        printf("%d is an Armstrong number\n", n);
    } else {
        printf("%d is not an Armstrong number\n", n);
    }
    
    return 0;
}

