#include<stdio.h>
int main()
{
	float pi,g,t,l;
	printf("enter a time\n");
	scanf("%f",&t);
	printf("enter the value of pi\n");
	scanf("%f",&pi);
	printf("enter the length\n");
	scanf("%f",&l);
	g=4*(pi*pi)*l)/t*t;
	printf("%f",g);
	return 0;
}
