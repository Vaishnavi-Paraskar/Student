#include<stdio.h>
int main()
{
	int a;
	printf("enter the number of the month\n"); 
	scanf("%d",&a);
	if (a == 2){
	printf("28 days or 29 days\n");
	}else if (a == 4){
	printf("30 days\n");
	}else if (a == 6){
	printf("30 days\n");
	}else if (a == 9){
	printf("30 days\n");
	}else if (a == 11){
	printf("30 days\n");
	}else{
	printf("31 days\n");
	}
	return 0;
}
