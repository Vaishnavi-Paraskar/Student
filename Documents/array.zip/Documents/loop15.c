#include<stdio.h>
int main()
{
	int n,i,count;
	printf("enter the number: ");
	scanf("%d",&n);
	count=0;
	for(i=1; i<=n; i++)
	if(n%i==0){
	count=count+1;
	}
	printf("count: %d\n",count);
	if(count==2){
	printf("n is a prime number\n");
	}else{
	printf("n is not a prime number\n");
	}
	return 0;
}
	
