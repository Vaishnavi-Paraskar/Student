#include<stdio.h>
int main()
{
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	for(int i=1; i<=n; i++){
	if(n%i==0){
	int count=0;
	for(int j=1; j<=i; j++){
	if(i%j==0){
	count=count+1;
	}
	}if(count==2){
	printf("%d\n",i);
	}
	}
	}
	return 0;
}
	
