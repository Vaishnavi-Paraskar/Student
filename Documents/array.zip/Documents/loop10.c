#include<stdio.h>
int main()
{
	int a,b,p,r,hcf,lcm;
	printf("enter the number: ");
	scanf("%d",&a);
	printf("enter the number: ");
	scanf("%d",&b);
	p=a*b;
	while(b > 0){
	r=a%b;
	a=b;
	b=r;
	}
	hcf=a;
	lcm=p/hcf;
	printf("%d\n%d\n",hcf,lcm);
	return 0;
}
	
