#include<stdio.h>
int main()
{
	int m,n,p,q,sum;
	printf("enter the number m: ");
	scanf("%d",&m);
	printf("enter the number n: ");
	scanf("%d",&n);
	printf("enter the number p: ");
	scanf("%d",&p);
	printf("enter the number q: ");
	scanf("%d",&q);
	sum=0;
	for(; m<=n; m++)
	if(m%p == 0 && m%q != 0){
	printf("%d\n",m);
	sum=sum+m;
	}
	printf("sum: %d\n",sum);
	return 0;
}
	
