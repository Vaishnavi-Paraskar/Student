#include<stdio.h>
int main()
{
	char romannumeral[100];
	printf("enter the roman numeral: ");
	scanf("%s",romannumeral);
	int decimalnum=romanToDecimal(romannumeral);
	printf("%s in decimal is %d",romannumeral,decimalnum);
	return 0;
}
