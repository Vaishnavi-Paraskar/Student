#include<stdio.h>
int main()
{
	int n,j;
	printf("enter the number n: ");
	scanf("%d",&n);
	int a[n];
	printf("enter the number what we insert(j): ");
	scanf("%d",&j);
	for(int i=0; i<n; i++){
	int b;
	printf("enter the number a: ");
	scanf("%d",&b);
	a[i]=b;
	}
	int k;
	printf("enter the number of position k: ");
	scanf("%d",&k);
	int i;
	for(i=n; i>k; i--){
	a[i]=a[i-1];
	}
	a[i]=j;
        n=n+1;
	for(int i=0; i<n; i++){
	printf("a[%d] = %d\n",i,a[i]);
	}
	return 0;
}
	
