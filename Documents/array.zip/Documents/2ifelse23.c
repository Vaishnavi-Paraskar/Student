#include<stdio.h>
int main()
{
	int num;
	printf("enter the number\n");
	scanf("%d",&num);
	if (num%10 == 3){
	printf("number ends with 3\n");
	}else if(num%10 == 7){
	printf("number ends with 7\n");
	}else{
	printf("%d\n",num);
	}
	return 0;
}
