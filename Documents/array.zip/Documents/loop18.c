//  tables from 1 to n 
#include<stdio.h>
int main()
{
	int n,i,j,a;
	printf("enter the number: ");
	scanf("%d",&n);
	for(i=1; i<=n; i++){
	for(j=1; j<=10; j++){
	a=j*i;
	printf("%d\n",a);
	}
	printf("\n");
	}
	return 0;
}
	
