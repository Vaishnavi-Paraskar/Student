#include<stdio.h>
int main()
{
	int c;
	float d;
	printf("enter the value of circumference of circle");
	scanf("%d",&c);
	d=c/(22/7);
	printf("%f",d);
	return 0;
}
	
	
