       // 10) Program To Check No Is Divisible by 7 Or Not

#include <stdio.h>
int main()
{
	int a;
	printf("enter the value of a\n");
	scanf("%d",&a);
	if ( a % 7==0){
	printf("number is divisible by 7\n");
	}else{
	printf("number is not Divisible by 7\n");
	}
	return 0;
}
