#include<stdio.h>
int main()
{
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	int a[n];
	for(int i=0; i<n; i++){
	int k;
	printf("enter the number k: ");
	scanf("%d",&k);
	a[i]=k;
	}
	for(int i=0; i<n; i++){
	int c=0;
	for(int j=0; j<n; j++){
	if (a[j]==a[i]){
	c=c+1;
	}
	}
	if(c==1){
	printf("%d\n",a[i]);
	}
	}
	return 0;
}
	
