#include <stdio.h>
int main()
{
	int num,a;
	printf("enter the number\n");
	scanf("%d",&num);
	a=num%10;
	printf("last digit of number is:%d\n",a);
	return 0;
}
