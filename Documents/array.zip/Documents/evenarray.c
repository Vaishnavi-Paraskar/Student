#include<stdio.h>
int main()
{
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	int a[n];
	int c=0;
	int i=0;
	int p=0;
	while(c<=n){
	if(p%2==0){
	a[i]=p;
	c=c+1;
	i=i+1;
	p=p+1;
	}
	p=p+1;
