#include<stdio.h>
int main()
{
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	for(int i=1; i<=n; i++){
	for(int j=1; j<=n; j++){
	if(i==n){
	printf("* ");
	}else if(j==i){
	printf("* ");
	}else if(j==1){
	printf("* ");
	}else{
	printf("  ");
	}
	}
	printf("\n");
	}
	return 0;
}
	
