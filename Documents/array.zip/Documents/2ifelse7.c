#include<stdio.h>
int main()
{
	int sp,cp,profit,loss;
	printf("enter the selling price\n");
	scanf("%d",&sp);
	printf("enter the cost price\n");
	scanf("%d",&cp);
	if (sp >= cp){
		if (sp == cp){
		printf("no profit no loss\n");
		}else{ 
		profit=sp-cp;
		printf("profit: %d\n",profit);
		}
		}
	else{
	loss=cp-sp;
	printf("loss: %d\n",loss);
	}

return 0;
}	
		
