#include<stdio.h>
int main()
{
	int a,b,c,d,e,total;
	float p;
	printf("enter the marks of hindi\n");
	scanf("%d",&a);
	printf("enter the marks of maths\n");
	scanf("%d",&b);
	printf("enter the marks of english\n");
	scanf("%d",&c);
	printf("enter the marks of science\n");
	scanf("%d",&d);
	printf("enter the marks of computer\n");
	scanf("%d",&e);
	total=a+b+c+d+e;
	p=(total*100)/500;
	printf("percentage:%f\n",p);
	return 0;
}
