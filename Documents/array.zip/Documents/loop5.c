#include<stdio.h>
int main()
{
	int i,n,product;
	printf("enter the number n: ");
	scanf("%d",&n);
	product=1;
	for(i=1; i<=n; i++){
	product=product*i;
	}
	printf("%d\n",product);
	return 0;
}
