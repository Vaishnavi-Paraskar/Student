#include<stdio.h>
int main()
{
int a,b,total;
printf("enter age of the person: ");
scanf("%d",&a);
printf("enter number of days: ");
scanf("%d",&b);
getchar();
char c;
printf("enter the gender of the person: ");
scanf("%c",&c);
if(c=='m'){
if(a>=18){
if(a<30){
total=700*b;
printf("%d\n",total);
}else if(a>=30){
if(a<=40){
total=800*b;
printf("%d\n",total);
}else{
printf("enter appropriate age\n");
}
}else{
printf("enter appropriate age\n");
}
}else{
printf("enter appropriate age\n");
}
}else if(c=='f'){
if(a>=18){
if(a<30){
total=750*b;
printf("%d\n",total);
}else if(a>=30){
if(a<=40){
total=850*b;
printf("%d\n",total);
}else{
printf("enter appropriate age\n");
}
}else{
printf("enter appropriate age\n");
}
}else{
printf("enter appropriate age\n");
}
}else{
printf("Invalid\n");
}
return 0;
}
