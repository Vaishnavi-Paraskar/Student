#include<stdio.h>
int main()
{
	int C;
	float F;
	printf("enter temperature in celcius\n");
	scanf("%d",&C);
	F=(9*C)/5+32;
	printf("temperature in fahrenheit:%f\n",F);
	return 0;
}
