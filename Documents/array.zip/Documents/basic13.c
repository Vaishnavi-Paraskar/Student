#include <stdio.h>
int main()
{
	float a,b,c,SP;
	printf("enter the side of a tringle\n");
	scanf("%f%f%f",&a,&b,&c);
	SP=(a+b+c)/2;
	printf("semiperimeter of a tringle is:%f\n",SP);
	return 0;
}
