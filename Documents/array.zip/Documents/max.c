#include<stdio.h>
int main()
{
	int n,a;
	printf("enter the number: ");
	scanf("%d",&n);
	printf("enter the number a: ");
	scanf("%d",&a);
	int max=a;
	int min=a;
	for(int i=1; i<n; i++){
	printf("enter the number a: ");
	scanf("%d",&a);
	if(a>max){
	max=a;
	}else if(a<min){
	min=a;
	}
	}
	printf("min: %d\nmax: %d\n",min,max);
	return 0;
}
	
	
