#include<stdio.h>
#include<string.h>
int main()
{
	char str[10];
	printf("enter the name of city\n");
	scanf("%s",str);
	if (strcmp(str,"delhi")==0){
	printf("Red Fort\n");
	}else if (strcmp(str,"agra")==0){
	printf("Tajmahal\n");
	}else if (strcmp(str,"jaipur")==0){
	printf("Jal mahal\n");
	}else{
	printf("invalid input\n");
	}
	return 0;
}
	
