#include<stdio.h>
int main()
{
	int a,b,c,d,e,total,P;
	printf("enter the marks of physics\n");
	scanf("%d",&a);
	printf("enter the marks of chemistry\n");
	scanf("%d",&b);
	printf("enter the marks of biology\n");
	scanf("%d",&c);
	printf("enter the marks of math\n");
	scanf("%d",&d);
	printf("enter the marks of computer\n");
	scanf("%d",&e);
	total=a+b+c+d+e;
	P=(total*100)/500;
	printf("%d\n",P);
	if (P >= 90){
	printf("Grade A\n");
	}else if (P >= 80){
	printf("Grade B\n");
	}else if (P >= 70){
	printf("Grade C\n");
	}else if (P >= 60){
	printf("Grade D\n");
	}else if (P >= 40){
	printf("Grade E\n");
	}else{
	printf("Grade F\n");
	}
	return 0;
}
	
	
	
