#include<stdio.h>         (some error)
int main()
{
	int i,sum,count,n,a;
	printf("enter the number: ");
	scanf("%d",&n);
	count=0;
	sum=0;
	for(i=1;count <= n; i++){
	if(i%3==0){
	a=i*i;
	sum=sum+a;
	count=count+1;
	}
	printf("%d",sum);
	}
	return 0;
}
	
