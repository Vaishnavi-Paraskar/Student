#include<stdio.h>
int main()
{
	int n,i,sum;
	printf("enter the number: ");
	scanf("%d",&n);
	sum=0;
	for(i=1; i<n; i++)
	if(n%i==0){
	sum=sum+i;
	}
	printf("sum: %d\n",sum);
	if(sum==n){
	printf("n is a perfect number\n");
	}else{
	printf("n is not a perfect number\n");
	}
	return 0;
}
	
