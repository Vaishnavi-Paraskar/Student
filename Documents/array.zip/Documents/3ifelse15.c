#include<stdio.h>
int main()
{
	int a,b,c,d;
	printf("enter the value of a\n");
	scanf("%d",&a);
	printf("enter the value of b\n");
	scanf("%d",&b);
	printf("enter the value of c\n");
	scanf("%d",&c);
	d=a+b+c;
	if(d == 180)
		if(a == b)
			if(b == c){
			printf("equilangular");
			}else if(a == 90){
			printf("right angled");
			}else if(b == 90){
			printf("right angled");
			}else if (c == 90){
			printf("right angled");
			}else if(a >90){
			printf("obtuse angled");
			}else if(b > 90){
			printf("obtuse angled");
			}else if(c > 90){
			printf("obtuse angled");
			}else{
			printf("acute angled");
			}
		else if(a == 90){
			printf("right angled");
			}else if(b == 90){
			printf("right angled");
			}else if (c == 90){
			printf("right angled");
			}else if(a >90){
			printf("obtuse angled");
			}else if(b > 90){
			printf("obtuse angled");
			}else if(c > 90){
			printf("obtuse angled");
			}else{
			printf("acute angled");
			}
	else{
	printf("not a valid set");
	}
	return 0;
}
			


















	
	
