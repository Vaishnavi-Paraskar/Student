// Create Array of First 10 odd Numbers

#include<stdio.h>
int main()
{	
	int A[10]={};
	int j=1;
	for(int i=0; i<10; i++){
	A[i]=j;
	j=j+2;
	}
	for(int i=0; i<10; i++){
	printf("A[%d]: %d\n",i,A[i]);
	}
	return 0;
}
