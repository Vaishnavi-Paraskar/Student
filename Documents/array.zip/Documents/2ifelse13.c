#include <stdio.h>
int main()
{
	int a;
	printf("enter the age of the person\n");
	scanf("%d",&a);
	if ( a >= 18){
	printf("person is eligible for voting\n");
	}else{
	printf("person is not eligible for voting\n");
	}
	return 0;
}
