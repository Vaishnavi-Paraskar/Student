#include<stdio.h>
int main()
{
	int n;
	printf("enter the binary number: ");
	scanf("%d",&n);
	int sum=0;
	int i=1;
	while(n!=0){
	int r=n%10;
	sum=sum+(r*i);
	i=i*2;
	n=n/10;
	}
	printf("decimal no: %d\n",sum);
	return 0;
}
	
