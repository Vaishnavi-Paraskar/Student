#include<stdio.h>
int main()
{
	int n,r;
	printf("enter the number\n");
	scanf("%d",&n);
	int a=0;
	while (n!=0){
	r=n%10;
	a=(a*10)+r;
	n=n/10;
	}
	printf("reverse of the number: %d\n",a);
	return 0;
}
