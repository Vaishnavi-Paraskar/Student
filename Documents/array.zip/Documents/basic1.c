		// Sum of two numbers
#include <stdio.h>
int main()
{
	int a,b,sum;
	printf("enter the number\n");
	scanf("%d%d",&a,&b);
	sum=a+b;
	printf("%d\n",sum);
	return 0;
}
	
