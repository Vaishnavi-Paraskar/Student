#include<stdio.h>
int main()
{
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	int a[n];
	for(int i=0; i<n; i++){
	int b;
	printf("enter the number b: ");
	scanf("%d",&b);
	a[i]=b;
	}
	int P=0;
	int N=0;
	int i=0;
	while (i<n){
	if(a[i]==0){
	i=i+1;
	}else if(a[i]>0){
	P=P+1;
	i=i+1;
	}else{
	N=N+1;
	i=i+1;
	}
	}
      printf("count of positive number: %d\n",P);
      printf("count of negative number: %d\n",N);
	return 0;
}
	
	
	
