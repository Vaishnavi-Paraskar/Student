#include<stdio.h>
int main()
{
int a,bonus;
printf("enter the amount\n");
scanf("%d",&a);
if(a>3000){
printf("bonus: %d\n",300);
}else if(a>1600){
bonus=(a*10)/100;
	if(bonus>240){
	printf("bonus: %d\n",240);
	}else{
	printf("bonus: %d\n",bonus);
	}
}else{
bonus=(a*15)/100;
if(bonus<100){
printf("bonus: %d\n",100);
}else{
printf("bonus: %d\n",bonus);
}
}
return 0;
}
