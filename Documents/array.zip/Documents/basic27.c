#include<stdio.h>
int main()
{
	int x,y,p,z;
	float b;
	printf("enter the amount\n");
	scanf("%d",&x);
	printf("enter the price of a book\n");
	scanf("%d",&y);
	printf("enter the price of a pen\n");
	scanf("%d",&p);
	z=x%y;
	b=z/p;
	printf("pens we can buy:%f\n",b);
	return 0;
}
