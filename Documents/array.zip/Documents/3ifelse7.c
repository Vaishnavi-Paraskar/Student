#include<stdio.h>
int main()
{
	int amount,notes;
	notes=0;
	printf("enter the amount\n");
	scanf("%d",&amount);
	if (amount >=2000){
	notes=amount/2000;
	printf("notes of 2000: %d\n",notes);
	amount=amount-(notes*2000);
	}
	if (amount >=1000){
        notes=amount/1000;
	printf("notes of 1000: %d\n",notes);
	amount=amount-(notes*1000);
	}
	if (amount >=500){
	notes=amount/500;
	printf("notes of 500: %d\n",notes);
	amount=amount-(notes*500);
	}
	if (amount >=200){
	notes=amount/200;
	printf("notes of 200: %d\n",notes);
	amount=amount-(notes*200);
	}
	if (amount >=100){
	notes=amount/100;
	printf("notes of 100: %d\n",notes);
	amount=amount-(notes*100);
	}
	if (amount >=50){
	notes=amount/50;
	printf("notes of 50: %d\n",notes);
	amount=amount-(notes*50);
	}
	if (amount >=20){
	notes=amount/20;
	printf("notes of 20: %d\n",notes);
        amount=amount-(notes*20);
        }
	if (amount >=10){
	notes=amount/10;
	printf("notes of 10: %d\n",notes);
	amount=amount-(notes*10);
	}
	if (amount >=5){
	notes=amount/5;
	printf("notes of 5: %d\n",notes);
	amount=amount-(notes*5);
	}							
	if (amount >=2){
	notes=amount/2;
	printf("notes of 2: %d\n",notes);
	amount=amount-(notes*2);
	}
	if (amount >=1){
	notes=amount/1;
	printf("notes of 1: %d\n",notes);
	amount=amount-(notes*1);
	}
	return 0;
}
