#include<stdio.h>
int main()
{
	int n,i,a,sum;
	printf("enter the number: ");
	scanf("%d",&n);
	sum=0;
	a=5;
	for(i=1; i<=n; i++){
	sum=sum+a;
	a=(a*10)+5;
	}
	printf("sum: %d\n",sum);
	return 0;
}
