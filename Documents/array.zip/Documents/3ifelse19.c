#include<stdio.h>
int main()
{
	int a,b,c,d,max1,max2,smax1,smax2;
	printf("enter the first number\n");
	scanf("%d",&a);
	printf("enter the second number\n");
	scanf("%d",&b);
	printf("enter the third number\n");
	scanf("%d",&c);
	printf("enter the fourth number\n");
	scanf("%d",&d);
	if(a>b){
	max1=a;
	smax1=b;
	}else{
	max1=b;
	smax1=a;
	}
		if(c>d){
		max2=c;
		smax2=d;
		}else{
		max2=d;
		smax2=c;
		}
			if(max1>max2)
				if(max2>smax1){
				printf("second max: %d\n",max2);
				}else{
				printf("second max: %d\n",smax1);
				}
			else if(max1>smax2){
			printf("second max: %d\n",max1);
			}else{
			printf("second max: %d\n",smax2);
			}
			return 0;
}
		
