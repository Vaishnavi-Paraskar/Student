#include<stdio.h>
int main()
{
int a,tax;
printf("enter the cost price of a bike\n");
scanf("%d",&a);
if(a>0)
	if(a>100000){
	tax=(a*15)/100;
	printf("%d\n",tax);
	}else if(a>50000){
	tax=(a*10)/100;
	printf("%d\n",tax);
	}else{
	tax=(a*5)/100;
	printf("%d\n",tax);
	}
else{
printf("invalid input\n");
}
return 0;
}
