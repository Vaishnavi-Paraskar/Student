#include<stdio.h>
int main()
{
	int i,n,sum;
	printf("enter the number n: ");
	scanf("%d",&n);
	for(i=1; i<=n; i++){
	sum=sum+i;
	}
	printf("sum of n numbers: %d\n",sum);
	return 0;
}
