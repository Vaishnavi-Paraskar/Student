#include<stdio.h>
int main()
{
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	int count=0;
	for(int i=1; i<=n; i++){
	int b=0;
	for(int j=2; j<=10; j++){
	if(i%j!=0){
	b=b+1;
	}
	}if(b==9){
	printf("%d\n",i);
	count=count+1;
	}
	}
	printf("count: %d\n",count);
}

