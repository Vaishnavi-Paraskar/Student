#include<stdio.h>
int main()
{
	int sp,cp,profit,p;
	printf("enter the selling price\n");
	scanf("%d",&sp);
	printf("enter the cost price\n");
	scanf("%d",&cp);
	if (sp > cp){
	profit=sp-cp;
	printf("profit: %d\n",profit);
	p=(profit*100)/cp;{
	printf("percentage: %d\n",p);
	}
	}else{
	printf("invalid\n");
	}
	return 0;
}
	
	
