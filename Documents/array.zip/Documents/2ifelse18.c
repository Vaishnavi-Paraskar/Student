#include<stdio.h>
int main()
{
	int t;
	printf("enter the temperature in degree celcius\n");
	scanf("%d",&t);
	if (t >= 100){
	printf("water boiling\n");
	}else{
	printf("water not boiling\n");
	}
	return 0;
}

