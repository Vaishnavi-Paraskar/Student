#include<stdio.h>
int main()
{
	float R,A,pi;
	printf("enter the radius of a circle\n");
	scanf("%f",&R);
	printf("enter the value of a pi\n");
	scanf("%f",&pi);
	A=pi*R*R;
	printf("area of a circle is:%f\n",A);
	return 0;
}
