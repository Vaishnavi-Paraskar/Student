#include<stdio.h>
int main()
{
	int n;
	printf("enter the number\n");
	scanf("%d",&n);
	if (n <= 9){
	printf("it is one digit number\n");
	}else if (n <= 99){
	printf("it is two digit number\n");
	}else if (n <= 999){
	printf("it is three digit number\n");
	}else{
	printf("it is more than three digit number\n");
	}
	return 0;
}
	
	
