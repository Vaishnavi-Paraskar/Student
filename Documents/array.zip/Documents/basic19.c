#include<stdio.h>
int main()
{
	float l,b,h,V;
	printf("enter the length of cuboid\n");
	scanf("%f",&l);
	printf("enter the breath of cuboid\n");
	scanf("%f",&b);
	printf("enter the height of cuboid\n");
	scanf("%f",&h);
	V=l*b*h;
	printf("volume of cuboid is:%f\n",V);
	return 0;
}
