#include<stdio.h>
int main()
{
	int a;
	printf("enter the number\n");
	scanf("%d",&a);
	if (a%5==0)
		if(a%11==0){
		printf("divisible by 5 and 11 both\n");
		}else{
		printf("divisible by 5\n");
		}
	else if(a%11==0){
	printf("divisible by 11\n");
	}else{
	printf("none\n");
	}
	return 0;
}
