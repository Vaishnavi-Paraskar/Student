#include<stdio.h>
int main()
{
	int a;
	printf("enter the number of day\n");
	scanf("%d",&a);
	if (a == 0){
	printf("monday\n");
	}else if (a == 1){
	printf("tuesday\n");
	}else if (a == 2){
	printf("wednesday\n");
	}else if ( a == 3){
	printf("thursday\n");
	}else if ( a == 4){
	printf("friday\n");
	}else if ( a == 5){
	printf("saturday\n");
	}else if ( a == 6){
	printf("sunday\n");
	}else{
	printf("invalid no\n");
	}
	return 0;
}
	
