#include<stdio.h>   some mistake
int main()
{
	int a[6]={5,4,3,2,1,0};
	int n=6;
	int b[n];
	int c=0;
	int j=0;
	for(int i=n-1; i>=0; i-=2){
	b[j]=a[i];
	j=j+1;
	c=c+1;
	}
	for(int j=0; j<c; j++){
	printf("%d",a[j]);
	}
	return 0;
}	
	
