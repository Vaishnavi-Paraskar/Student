#include<stdio.h>
int main()
{
	int a[10]={};
	int j=3;
	for(int i=0; i<10; i++){
	int p=j*(i+1);
	a[i]=p;
	}
	for(int i=0; i<10; i++){
	printf("%d * %d = %d\n",j,(i+1),a[i]);
	}
	return 0;
}
