#include <stdio.h>
int main()
{
	float l,b,A,P;
	printf("enter the length of rectangle\n");
	scanf("%f",&l);
	printf("enter the breadth of rectangle\n");
	scanf("%f",&b);
	A =l*b;
	P=2*(l+b);
	printf("area is:%f\n",A);
	printf("perimeter is:%f\n",P);
	return 0;
}

