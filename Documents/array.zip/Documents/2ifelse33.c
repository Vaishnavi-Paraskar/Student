#include<stdio.h>
int main()
{
	int bs,HRA,DA,GS;
	printf("enter the basic salary of the employee\n");
	scanf("%d",&bs);
	if (bs <= 10000){
	HRA=(bs*20)/100;
	DA=(bs*80)/100;
	GS=bs+HRA+DA;
	printf("HRA :%d\n",HRA);
        printf("DA :%d\n",DA);
	printf("Gross Salary :%d\n",GS);
	}else if (bs <= 20000){
	HRA=(bs*25)/100;
	DA=(bs*90)/100;
	GS=bs+HRA+DA;
	printf("HRA :%d\n",HRA);
	printf("DA :%d\n",DA);
	printf("Gross Salary :%d\n",GS);
	}else{
	HRA=(bs*30)/100;
	DA=(bs*95)/100;
	GS=bs+HRA+DA;
	printf("HRA :%d\n",HRA);
	printf("DA :%d\n",DA);
	printf("Gross Salary :%d\n",GS);
	}
	return 0;
}
	 
	
	
	
