#include<stdio.h>
int main()
{
	int num;
	printf("enter the number\n");
	scanf("%d",&num);
	if (num%4 == 0){
	printf("%d\n",num+1);
	}else{
	printf("%d\n",num-1);
	}
	return 0;
}
