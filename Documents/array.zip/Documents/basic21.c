#include <stdio.h>
int main()
{
	int a,b,c;
	printf("enter the number\n");
	scanf("%d",&a);
	printf("enter the number\n");
	scanf("%d",&b);
	c=a%b;
	printf("remainder of number is:%d\n",c);
	return 0;
}
