				// Second Max Between 3 Numbers
#include<stdio.h>
int main()
{
	int a,b,c,max,smax;
	printf("enter the first number\n");
	scanf("%d",&a);
	printf("enter the second number\n");
	scanf("%d",&b);
	printf("enter the third number\n");
	scanf("%d",&c);
	if(a>b){
	max=a;
	smax=b;
	}else{
	max=b;
	smax=a;
	}
		if(max>c){
			if(c>smax){
			printf("second max: %d\n",c);
			}else{
			printf("second max: %d\n",smax);
			}
		}else{
		printf("second max: %d\n",max);
		}
	return 0;
}
	
