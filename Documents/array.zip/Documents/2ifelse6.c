// 6) Program To Check It Is Rectangle Or Square

#include <stdio.h>
int main()
{
	float ab,bc;
	printf("enter the the value of side ab\n");
	scanf("%f",&ab);
	printf("enter the the value of side bc\n");
	scanf("%f",&bc);
	if (ab == bc){
	printf("square\n");
	}else{
	printf("rectangle\n");
	}
	return 0;
}
	
	
