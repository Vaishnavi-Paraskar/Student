#include<stdio.h>
int main()
{
	int a,b,d;
	float c;
	printf("enter the value of a\n");
	scanf("%d",&a);
	printf("enter the value of b\n");
	scanf("%d",&b);
	c=a/b;
	d=c*b;
	printf("closest number:%d\n",d);
	return 0;
}
	
