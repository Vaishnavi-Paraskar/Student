#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int fact=1;
	while (fact<n){
	if (n % fact==0){
	printf("%d\n",fact);
	fact=fact+1;
	}else{
	fact++;
	}
	}
	return 0;
}
