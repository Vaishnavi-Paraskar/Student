#include<stdio.h>
int main()
{
	int n,k;
	printf("enter the number: ");
	scanf("%d",&n);
	int a[n];
	printf("enter the position of number we delete k: ");
	scanf("%d",&k);
	for(int i=0; i<n; i++){
	int b;
	printf("enter the number: ");
	scanf("%d",&b);
	a[i]=b;
	}
	int i;
	for(i=k; i<(n-1); i++){
	int t=a[i];
	a[i]=a[i+1];
	}
	n=n-1;
	for(int i=0; i<n; i++){
	printf("a[%d] = %d\n",i,a[i]);
	}
	return 0;
}	
	
	
