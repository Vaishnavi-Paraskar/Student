// 8) Program To Check No Is Smallest 4 Digit No Or Not

#include<stdio.h>
int main()
{
	int a;
	printf("enter the value of a\n");
	scanf("%d",&a);
	if ( a == 1000){
	printf("it is a smallest 4 digit no\n");
	}else{
	printf("it is not a smallest 4 digit no\n");
	}
	return 0;
}
