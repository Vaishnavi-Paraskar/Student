#include<stdio.h>
int main()
{
	int a;
	float total,totalbill;
	printf("enter the number of unit\n");
	scanf("%d",&a);
	if(a <=50){
	total=a*0.50;
	printf("total: %f\n",total);
	}else if(a <= 150){
	total=50*0.50+(a-50)*0.75;
	printf("total: %f\n",total);
	}else if(a <= 250){
	total=50*0.50+100*0.75+(a-150)*1.20;
	printf("total: %f\n",total);
	}else{
	total=(50*0.50+100*0.75+100*1.20+(a-250)*1.50);
	printf("total: %f\n",total);
	totalbill=(total*20)/100+total;
	printf("totalbill: %f\n",totalbill);
	}
	return 0;
}
