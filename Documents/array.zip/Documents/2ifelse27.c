#include<stdio.h>
int main()
{
	float l,b,a,p;
	printf("enter the length of rectangle\n");
	scanf("%f",&l);
	printf("enter the breadth of rectangle\n");
	scanf("%f",&b);
	a=l*b;
	p=2*(l+b);
	if (a == p){
	printf("both are equal\n");
	}else if (a > p){
	printf("area is greater\n");
	}else{
	printf("perimeter is greater\n");
	}
	return 0;
}
	
