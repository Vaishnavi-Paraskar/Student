#include <stdio.h>
int main()
{
	float a,V;
	printf("enter the side of a cube\n");
	scanf("%f",&a);
	V=a*a*a;
	printf("volume of cube is:%f\n",V);
	return 0;
}
