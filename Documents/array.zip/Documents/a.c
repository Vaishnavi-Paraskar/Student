#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int sum=0;
	int m=1,r,a;
	if (n%2==0){
	while (n!=0){
	r=n%10;
	sum=sum+r;
	n=n/10;
	}
	printf("sum: %d\n",sum);
	}else{
	while (n!=0){
	a=n%10;
	m=m*a;
	n=n/10;
	}
	printf("multiplication: %d\n",m);
	}
	return 0;
}
	
	
