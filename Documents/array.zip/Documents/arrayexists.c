#include<stdio.h>
int main()
{
	int array[7]={1,2,3,4,5,6,7};
	int a;
	printf("enter the number: ");
	scanf("%d",&a);
	for(int i=0; i<7; i++){
	if(array[i] == a){
	printf("number exists in array\n");
	}
	}
	return 0;
}
