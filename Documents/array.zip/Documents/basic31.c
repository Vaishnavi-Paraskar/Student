#include<stdio.h>
int main()
{
	int s,v,finalprice;
	printf("enter the number of samosas\n");
	scanf("%d",&s);
	printf("enter the number of vadapav\n");
	scanf("%d",&v);
	finalprice=(s*15)+(v*12);
	printf("final price is:%d\n",finalprice);
	return 0;
}
	
	
