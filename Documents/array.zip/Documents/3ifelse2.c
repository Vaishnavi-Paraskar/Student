#include<stdio.h>
int main()
{
	int d,m,y;
	printf("enter the date\n");
	scanf("%d",&d);
	printf("enter the number of month\n");
	scanf("%d",&m);
	printf("enter the year\n");
	scanf("%d",&y);
	if (y >0){
		if(d >= 1)
			if(d <= 31)
				if(m >= 1)
					if(m <= 12){
					printf("year is valid\n");
					}else{
					printf("year is not valid\n");
					}
				else{
				printf("year is not valid\n");
				}
			else{
			printf("year is not valid\n");
			}
		else{
		printf("year is not valid\n");
		}
	}else{
	printf("year is not valid\n");
	}
	return 0;
}
	
	
