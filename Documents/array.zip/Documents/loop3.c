#include<stdio.h>
int main()
{
	int i,sum;
	sum=0;
	for(
	{
