#include <stdio.h>
int main()
{
	int a;
	printf("enter the value of a\n");
	scanf("%d",&a);
	if ( a % 5==0){
	printf("Hello\n");
	}else{
	printf("Bye\n");
	}
	return 0;
}
