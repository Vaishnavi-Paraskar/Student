#include<stdio.h>
int main()
{
	int a;
	printf("enter the year\n");
	scanf("%d",&a);
	if (a % 100 == 0){
	printf("year is divisible 100\n");
	}else{
	printf("year is not divisible by 100\n");
	}
	return 0;
}
