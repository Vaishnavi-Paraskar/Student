			3) //daily wage of workers
#include <stdio.h>
int main()
{
	int a,b;
	printf("enter the numbers of hours\n"a);
	scanf("%d",&a);
	printf("enter the hourly wage rate\n"b);
	scanf("%d",&b);
	int daily wage;
	daily wage=a*b;
	printf("%d",daily wage);
	return 0;
}

