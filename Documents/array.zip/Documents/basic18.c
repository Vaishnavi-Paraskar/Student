#include<stdio.h>
int main()
{
	float l,w,h,LSA,TSA;
	printf("enter the side of cuboid\n");
	scanf("%f",&l);
	printf("enter the width of cuboid\n");
	scanf("%f",&w);
	printf("enter the height of cuboid\n");
	scanf("%f",&h);
	LSA=2*h*(l+w);
	TSA=2*((l*w)+(w*h)+(l*h));
	printf("lateral surface area of cuboid is:%f\n",LSA);
	printf("total surface area of cuboid is:%f\n",TSA);
	return 0;
}
