#include<stdio.h>
int main()
{
	int a,b,c,d,e,total1,total2;
	printf("enter the marks of subjects of student x\n");
	scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
	total1=a+b+c+d+e;
	printf("enter the marks of subjects of student y\n");
	scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
	total2=(a+b+c+d+e);
	printf("marks of student X: %d\n",total1);
	printf("marks of student y: %d\n",total2);
	if (total1 > total2){
	printf("student X is topper\n");
	}else{
	printf("student Y is topper\n");
	}
	return 0;
}
