#include<stdio.h>
int main()
{
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	int a[n];
	for(int i=0; i<n; i++){
	int k;
	printf("enter the number k: ");
	scanf("%d",&k);
	a[i]=k;
	}
	int p[n];
	int i;
	int b=a[i];
	for(int i=0; i<n; i++){
	p[i]=b;
	b=b+1;
	}
	int c=0;
	for(int i=0; i<n; i++){
	if(a[i]==p[i]){
	c=c+1;
	}
	}
	printf("count: %d\n",c);
	if(c==n){
	printf("it is consecutive array\n");
	}else{
	printf("it is not consecutive array\n");
	}
	return 0;
}
	
	
	

