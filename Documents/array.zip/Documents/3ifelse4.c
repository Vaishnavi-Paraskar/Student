#include<stdio.h>
int main()
{
	int n,total;
	printf("enter the value of n\n");
	scanf("%d",&n);
	if (n <= 100){
	printf("no charge\n");
	}else if(n <= 200){
	total=(100*0)+(n-100)*5;
	printf("%d\n",total);
	}else{
	total=(100*0)+(100*5)+(n-200)*10;
	printf("%d\n",total);
	}
	return 0;
}
